# @globalwatch-hub/synertia-ui

Synertia UI design system as an installable package: the navy sidebar + header
chrome, Montserrat wiring, brand watermark, translucent cards, and a config‑driven
login — parameterised per client. Reference implementation: **DS Matrix** (DS Crédito).

> **The chrome is the Synertia brand** (identical across platforms). **The content
> area is the client brand** — you pass the client logo, names, accent colour and
> nav via config.

---

## Install (GitHub Packages)

The package is private to the `GlobalWatch-hub` org on GitHub Packages. In the
**consumer** repo add an `.npmrc`:

```
@globalwatch-hub:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

`GITHUB_TOKEN` needs the `read:packages` scope. Then:

```bash
npm install @globalwatch-hub/synertia-ui
```

## Wire it up (Next.js 14 + Tailwind)

**1. Transpile the package** — `next.config.js`:

```js
module.exports = { transpilePackages: ['@globalwatch-hub/synertia-ui'] };
```

**2. Tailwind preset + content** — `tailwind.config.ts`:

```ts
export default {
  presets: [require('@globalwatch-hub/synertia-ui/tailwind-preset')],
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './node_modules/@globalwatch-hub/synertia-ui/src/**/*.{ts,tsx}',
  ],
  theme: { extend: { colors: { /* your client accent ramp, optional */ } } },
};
```

**3. Global styles + font** — `app/globals.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
@import '@globalwatch-hub/synertia-ui/styles.css';
```

`app/layout.tsx` (Montserrat via the `--font-sans` variable):

```tsx
import { Montserrat } from 'next/font/google';
const montserrat = Montserrat({ subsets:['latin'], weight:['400','500','600','700'], variable:'--font-sans', display:'swap' });
// <html className={montserrat.variable}><body className="font-sans">…</body></html>
```

**4. Copy the watermark asset** into your `public/`:

```
node -e "require('fs').copyFileSync(require.resolve('@globalwatch-hub/synertia-ui/assets/watermark.png'),'public/logo-synertia-watermark.png')"
```

Also copy the Synertia brand logo (`assets/logo.png`) into `public/` for the sidebar.

## Use the chrome

```tsx
import { SynertiaShell, UserPill, IconContacts, IconDashboard, IconLeads, IconNewsletter, IconReport } from '@globalwatch-hub/synertia-ui';

const config = {
  brandLogoSrc: '/logo-synertia.png',
  clientLogoSrc: '/client-logo.svg',
  productName: 'DS Matrix',
  clientName: 'DS Crédito Ramada',
  accent: '#a91b60',
  nav: [
    { href:'/contactos', label:'Contactos',     icon:<IconContacts/> },
    { href:'/dashboard', label:'Dashboard',     icon:<IconDashboard/> },
    { href:'/leads',     label:'Leads',         icon:<IconLeads/> },
    { href:'/newsletter',label:'Newsletter',    icon:<IconNewsletter/> },
    { href:'/recap',     label:'Recap semanal', icon:<IconReport/> },
  ],
  liveLink: { href:'/clientes-live', label:'CRM em direto' },
};

// app/layout.tsx (inside <body>):
<SynertiaShell config={config} userSlot={<UserPill name={user} onLogout={logout} />}>
  {children}
</SynertiaShell>
```

## Welcome cards & login

```tsx
import { BrandCard, SynertiaLoginShell, SynertiaField, IconUser, IconLock } from '@globalwatch-hub/synertia-ui';

<BrandCard href="/leads" title="Leads" desc="Captação e reativação" color="#3b6cf0" icon={<IconLeads className="h-9 w-9" />} />

<SynertiaLoginShell clientLogoSrc="/client-logo.svg" productName="DS Matrix" accent="#a91b60">
  <form className="space-y-3">
    <SynertiaField icon={<IconUser/>} placeholder="Utilizador" />
    <SynertiaField icon={<IconLock/>} type="password" placeholder="Palavra-passe" />
    <button className="btn-primary w-full justify-center py-2.5">Entrar</button>
  </form>
</SynertiaLoginShell>
```

## Exports

`SynertiaShell`, `SynertiaLoginShell`, `SynertiaField`, `BrandCard`, `UserPill`,
`Icon` + `Icon{Contacts,Dashboard,Leads,Newsletter,Report,ArrowRight,ChevronLeft,User,Lock}`,
types `SynertiaConfig`/`SynertiaNavItem`; plus `./styles.css`, `./tailwind-preset`,
`./assets/*`.

## Updating an existing platform

1. Bump in the consumer: `npm update @globalwatch-hub/synertia-ui` (or pin a version).
2. Re-check the [CHANGELOG](./CHANGELOG.md) for any new required config/props.
3. Rebuild + deploy. The client tokens stay in **your** config — only the chrome
   moves with the package.

Semver: **patch** = visual/bugfix, **minor** = new exports/optional props,
**major** = breaking config/API.

## Publishing (maintainers)

From this repo, with a token that has `write:packages`:

```bash
npm version <patch|minor|major>
npm publish     # uses publishConfig → npm.pkg.github.com
git push --follow-tags
```
