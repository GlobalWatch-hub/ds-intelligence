"""Generate the navy Synertia watermark (transparent, low alpha) from the
full-colour logo. Tune MAXA for intensity: 20 light, 34 medium, 64 strong.

    python make-watermark.py            # -> logo-synertia-watermark.png
"""
from PIL import Image

SRC = "logo-synertia.png"
OUT = "logo-synertia-watermark.png"
BG = (13, 19, 42)     # the logo's navy background
NAVY = (13, 19, 42)   # watermark fill colour
MAXA = 20             # peak alpha

src = Image.open(SRC).convert("RGB")
w, h = src.size
out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
sp, op = src.load(), out.load()
for y in range(h):
    for x in range(w):
        r, g, b = sp[x, y]
        d = ((r - BG[0]) ** 2 + (g - BG[1]) ** 2 + (b - BG[2]) ** 2) ** 0.5
        t = (d - 40) / 90  # foreground = far from the navy background
        if t > 0:
            op[x, y] = (NAVY[0], NAVY[1], NAVY[2], int(MAXA * min(t, 1.0)))
out.crop(out.getbbox()).save(OUT)  # crop to the mark for clean centring
print("saved", OUT)
