import Link from 'next/link';
import type { ReactNode } from 'react';
import { IconArrowRight } from './icons';

/**
 * Welcome-page brand card (the "Nossas Soluções" pattern): a coloured outline
 * icon, title, description and an arrow. Translucent so the watermark reads
 * through. `color` is the per-card brand accent (violet/blue/teal/indigo…).
 */
export function BrandCard({
  href,
  title,
  desc,
  color,
  icon,
}: {
  href: string;
  title: string;
  desc: string;
  color: string;
  icon: ReactNode;
}) {
  return (
    <Link
      href={href}
      className="group block text-left rounded-2xl shadow-card bg-white/40 backdrop-blur-sm p-8 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl hover:bg-white/60"
    >
      <div
        className="h-16 w-16 rounded-2xl flex items-center justify-center mb-6"
        style={{ backgroundColor: `${color}1f`, color }}
      >
        {icon}
      </div>
      <div className="text-xl font-semibold text-ink-900">{title}</div>
      <div className="text-sm text-ink-400 mt-2">{desc}</div>
      <div
        className="mt-6 inline-flex items-center text-sm font-medium transition-transform group-hover:translate-x-1"
        style={{ color }}
      >
        <IconArrowRight />
      </div>
    </Link>
  );
}
