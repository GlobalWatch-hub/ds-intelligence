import type { ReactNode } from 'react';

export type SynertiaNavItem = {
  href: string;
  label: string;
  icon: ReactNode;
};

export type SynertiaConfig = {
  /** Synertia brand logo shown at the top of the sidebar (navy-friendly). */
  brandLogoSrc: string;
  /** Client logo shown in the header lockup (and reusable elsewhere). */
  clientLogoSrc: string;
  /** Platform/product name, e.g. "DS Matrix". */
  productName: string;
  /** Client name shown after the product, e.g. "DS Crédito Ramada". */
  clientName: string;
  /** Client accent colour (hex). Drives buttons / focus / arrows via --accent. */
  accent: string;
  /** Primary navigation items. */
  nav: SynertiaNavItem[];
  /** Optional emerald "live" link below the nav. */
  liveLink?: { href: string; label: string };
  /** Home route (default "/"). The back button is hidden here. */
  homeHref?: string;
  /** Routes rendered bare, without the chrome (default ["/login"]). */
  bareRoutes?: string[];
};
