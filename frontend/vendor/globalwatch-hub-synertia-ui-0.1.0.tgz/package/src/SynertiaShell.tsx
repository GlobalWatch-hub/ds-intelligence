'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import type { CSSProperties, ReactNode } from 'react';
import type { SynertiaConfig } from './config';
import { IconChevronLeft } from './icons';

const NAVY = '#0d132a';

/**
 * The Synertia chrome: fixed navy sidebar (brand logo + nav + user slot) and a
 * white top header (back button + centred client lockup) wrapping the content.
 * Renders bare on `bareRoutes` (default ["/login"]). Sets the `--accent` CSS
 * variable from config so buttons/links pick up the client colour.
 */
export function SynertiaShell({
  config,
  userSlot,
  children,
}: {
  config: SynertiaConfig;
  userSlot?: ReactNode;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const home = config.homeHref ?? '/';
  const bare = config.bareRoutes ?? ['/login'];

  if (bare.includes(pathname)) {
    return <main className="max-w-7xl mx-auto px-6 py-8">{children}</main>;
  }

  const fullWidth = pathname === '/dashboard';
  const rootStyle = { ['--accent' as any]: config.accent } as CSSProperties;

  return (
    <div style={rootStyle}>
      <aside
        className="fixed inset-y-0 left-0 w-60 z-30 flex flex-col text-white"
        style={{ backgroundColor: NAVY }}
      >
        <div className="px-5 py-5">
          <Link href={home} aria-label="Synertia" className="inline-flex">
            <img src={config.brandLogoSrc} alt="Synertia" className="h-8 w-auto" />
          </Link>
        </div>

        <nav className="flex-1 px-3 py-2 flex flex-col gap-1 text-sm">
          {config.nav.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + '/');
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-colors ${
                  active
                    ? 'bg-white/15 text-white font-medium'
                    : 'text-white/70 hover:text-white hover:bg-white/10'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </Link>
            );
          })}
          {config.liveLink && (
            <Link
              href={config.liveLink.href}
              className="flex items-center gap-3 rounded-lg px-3 py-2 font-medium text-emerald-300 hover:text-emerald-200 hover:bg-white/10"
            >
              <span className="inline-flex h-5 w-5 items-center justify-center shrink-0">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              </span>
              <span>{config.liveLink.label}</span>
            </Link>
          )}
        </nav>

        {userSlot && <div className="px-3 py-3 border-t border-white/10">{userSlot}</div>}
      </aside>

      <div className="ml-60">
        <header className="sticky top-0 z-20 bg-white border-b border-ink-100">
          <div className="relative h-16 flex items-center justify-center px-6">
            {pathname !== home && (
              <button
                onClick={() => router.back()}
                aria-label="Voltar"
                className="absolute left-4 inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm text-ink-500 hover:bg-ink-50"
              >
                <IconChevronLeft />
                Voltar
              </button>
            )}
            <Link href={home} aria-label={config.productName} className="flex items-center gap-3">
              <img src={config.clientLogoSrc} alt={config.clientName} className="h-12 w-12" />
              <span className="text-2xl font-semibold text-ink-900">
                {config.productName}
                <span className="ml-2 text-base text-ink-400 font-normal">· {config.clientName}</span>
              </span>
            </Link>
          </div>
        </header>
        <main className={`${fullWidth ? 'w-full' : 'max-w-7xl mx-auto'} px-6 py-8`}>{children}</main>
      </div>
    </div>
  );
}
