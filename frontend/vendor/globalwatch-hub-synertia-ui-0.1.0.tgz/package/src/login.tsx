'use client';
import type { CSSProperties, InputHTMLAttributes, ReactNode } from 'react';

/**
 * Icon-prefixed login field that floats on the background (no solid panel) —
 * translucent, with a divider between the icon and the input.
 */
export function SynertiaField({
  icon,
  ...inputProps
}: { icon: ReactNode } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="flex items-stretch rounded-xl border border-white/70 bg-white/70 backdrop-blur-sm shadow-sm overflow-hidden focus-within:ring-2 focus-within:ring-[color:var(--accent)]">
      <span className="flex items-center px-3 border-r border-ink-200/60 text-ink-500">{icon}</span>
      <input className="flex-1 bg-transparent px-3 py-2.5 text-sm focus:outline-none" {...inputProps} />
    </div>
  );
}

/**
 * Login layout: client logo + product title centred over the watermark, with
 * your form (`children`) below. No white card — fields float on the background.
 */
export function SynertiaLoginShell({
  clientLogoSrc,
  productName,
  accent,
  subtitle = 'Introduza as suas credenciais de acesso.',
  children,
}: {
  clientLogoSrc: string;
  productName: string;
  accent: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const style = { ['--accent' as any]: accent } as CSSProperties;
  return (
    <div className="min-h-[78vh] flex items-center justify-center" style={style}>
      <div className="w-full max-w-md space-y-6">
        <div className="flex flex-col items-center text-center">
          <img src={clientLogoSrc} alt={productName} className="h-14 w-14 mb-3" />
          <h1 className="text-xl font-semibold text-ink-900">{productName}</h1>
          <p className="text-sm text-ink-400 mt-1">{subtitle}</p>
        </div>
        {children}
      </div>
    </div>
  );
}
