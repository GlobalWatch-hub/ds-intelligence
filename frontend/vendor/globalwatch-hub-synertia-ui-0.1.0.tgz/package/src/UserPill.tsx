'use client';

/**
 * Compact translucent user pill for the sidebar bottom. Presentational only —
 * wire `onLogout` to your auth. `name` falls back to "Utilizador".
 */
export function UserPill({ name, onLogout, logoutLabel = 'Sair' }: { name?: string | null; onLogout: () => void; logoutLabel?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-full border border-white/15 bg-white/10 pl-3 pr-1 py-0.5">
      <span className="text-xs text-white/80 font-medium truncate">{name ?? 'Utilizador'}</span>
      <button
        onClick={onLogout}
        className="rounded-full bg-white/15 border border-white/15 px-2 py-0.5 text-[11px] text-white/75 hover:text-white hover:bg-white/25"
      >
        {logoutLabel}
      </button>
    </div>
  );
}
