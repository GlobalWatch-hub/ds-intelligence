# Changelog

All notable changes to `@globalwatch-hub/synertia-ui`. Follows semver:
**patch** = visual/bugfix · **minor** = new exports/optional props · **major** = breaking API.

## 0.1.0 — 2026-06-27

Initial extraction from the DS Matrix platform.

- `SynertiaShell` — navy sidebar (brand logo + nav + user slot) + white top header
  (back button + centred client lockup); bare on `/login`; sets `--accent`.
- `SynertiaLoginShell` + `SynertiaField` — config-driven login, floating
  translucent fields with icon prefixes (no solid card).
- `BrandCard` — welcome "Nossas Soluções" card (coloured outline icon + arrow).
- `UserPill` — compact sidebar user/logout pill.
- Outline icon set (`IconContacts/Dashboard/Leads/Newsletter/Report/...`).
- `tailwind-preset.cjs` (navy + ink scale + Montserrat var + card shadow).
- `styles.css` (page bg + centred watermark, `.card`, buttons, chip; `--accent`,
  `--synertia-watermark` tokens).
- `assets/` — Synertia logo, watermark PNG, and `make-watermark.py` generator.
