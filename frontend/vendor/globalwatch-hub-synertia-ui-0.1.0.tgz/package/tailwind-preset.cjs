/**
 * Synertia Tailwind preset — the fixed brand tokens shared by every platform.
 * Usage in a consumer's tailwind.config:
 *   presets: [require('@globalwatch-hub/synertia-ui/tailwind-preset')]
 * The client ACCENT colour is per-platform and stays in the consumer config
 * (the components read it from the `--accent` CSS variable, set by SynertiaShell).
 */
module.exports = {
  theme: {
    extend: {
      colors: {
        navy: '#0d132a',
        ink: {
          50: '#f7f8fb',
          100: '#eef0f5',
          200: '#e2e6ee',
          300: '#cbd2de',
          400: '#727a8a',
          500: '#525a6b',
          700: '#1f2533',
          900: '#0c0f17',
        },
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15,23,42,.04), 0 4px 12px rgba(15,23,42,.04)',
      },
    },
  },
};
